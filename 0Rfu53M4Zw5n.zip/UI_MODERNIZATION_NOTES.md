# Modern UI pass — applied locally, not pushed to GitHub

This zip is a local copy of `libraryofmiao/new-app` @ main with a UI/UX
modernization pass applied for a nicer, more interactive app. Nothing was
changed on GitHub. Material Components was already a dependency in
app/build.gradle.kts, so no new dependencies were added.

## What changed, and why

**Typography**
- The theme's `android:fontFamily` was set to `"sans"`, which is not a
  recognized Android system font family name — it silently fell back to
  the default font. Fixed to the valid `"sans-serif"`.
- Section titles, card headlines, and book/announcement titles now use an
  explicit `sans-serif-medium` bold weight for a clearer visual hierarchy,
  instead of the ambient (and here, broken) theme font plus a bold flag.

**Inputs**
- Username, password, and catalogue search were plain `EditText` fields
  with a hand-drawn rounded background and no keyboard affordances.
  Replaced with Material `TextInputLayout` + `TextInputEditText`:
  floating labels, an outlined box, and (for the password field) a
  built-in show/hide toggle icon — there was previously no way to reveal
  the password at all.
- Keyboard actions now work: pressing "Done" on the password field submits
  login, and pressing "Search" on the catalogue field runs the search —
  previously both required tapping a button, with no keyboard shortcut.

**Buttons**
- Custom `Button` views styled with hand-drawn `GradientDrawable`
  backgrounds and `stateListAnimator = null` (which removed all press
  feedback) are now `MaterialButton`s — filled for primary actions,
  outlined for secondary ones — with proper ripple feedback and elevation.
  This also fixed a real affordance problem: secondary buttons
  (`primary = false`) were plain white with no border, visually
  indistinguishable from the white cards behind them.

**Cards**
- The `card()` helper used a `FrameLayout` with a flat drawable background
  (no real depth). Now a `MaterialCardView` with a subtle stroke and
  elevation, and clickable cards (catalogue results) get a proper ripple
  instead of no touch feedback at all.

**Bottom navigation**
- The nav bar was a hand-rolled row of `LinearLayout`s using emoji
  characters (⌂ ⌕ ▣ ●) as icons. Replaced with a themed
  `BottomNavigationView` using proper vector icons (home / search / book /
  person), so it renders consistently across devices and fonts instead of
  depending on emoji glyph support.

**Loading states**
- Plain "Loading…" text is now a small `CircularProgressIndicator` next to
  the label, used consistently across Home, Catalogue, My Books, and
  Issue History. "My Books" previously showed nothing at all while the
  network call was in flight — it now shows a loading state like every
  other screen.

**Motion**
- Subtle fade-ins on login and on every section switch — the previous
  version snapped content in and out instantly.

**Manifest**
- Added `android:windowSoftInputMode="adjustResize"` so the keyboard
  doesn't cover the new input fields.

**Not changed**
- No app logic, network calls, JSON parsing, or business rules were
  touched — only how the UI is built and styled. The screen flow (Home /
  Catalogue / My Books / Account) and all API endpoints are identical to
  what's on GitHub.

## Build in GitHub Codespaces / VS Code

```
chmod +x ./gradlew
./gradlew :app:assembleDebug --stacktrace
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`
