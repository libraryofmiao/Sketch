package `in`.miaolibrary.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread
import com.google.android.material.R as MaterialR

class MainActivity : AppCompatActivity() {
    private val gateway = "https://api.miaolibrary.in"
    private val bg = Color.rgb(248, 245, 239)
    private val ink = Color.rgb(27, 43, 58)
    private val muted = Color.rgb(105, 112, 117)
    private lateinit var content: FrameLayout
    // Exact active-loan identifiers used to keep current loans out of Previous Issues.
    private val currentIssueKeys = mutableSetOf<String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("session", MODE_PRIVATE)
    private fun token() = prefs().getString("access_token", null)
    private fun username() = prefs().getString("username", "Patron") ?: "Patron"

    private fun headlineTypeface(): Typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)

    private fun text(
        value: String,
        size: Float = 16f,
        color: Int = ink
    ) = TextView(this).apply {
        this.text = value
        textSize = size
        setTextColor(color)
    }

    private fun shape(
        color: Int = Color.WHITE,
        radius: Int = 20
    ) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun card(view: View): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(20).toFloat()
        cardElevation = dp(2).toFloat()
        strokeWidth = dp(1)
        strokeColor = ContextCompat.getColor(context, R.color.outline)
        setCardBackgroundColor(Color.WHITE)
        setContentPadding(dp(18), dp(16), dp(18), dp(16))
        addView(view, FrameLayout.LayoutParams(-1, -2))
    }

    private fun loadingRow(label: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(
            com.google.android.material.progressindicator.CircularProgressIndicator(this@MainActivity).apply {
                isIndeterminate = true
                trackThickness = dp(3)
                indicatorSize = dp(20)
            },
            LinearLayout.LayoutParams(dp(20), dp(20))
        )
        addView(
            text(label, 14f, muted).apply { setPadding(dp(10), 0, 0, 0) },
            LinearLayout.LayoutParams(-2, -2)
        )
    }

    private fun button(
        label: String,
        primary: Boolean = true
    ): MaterialButton {
        val btn = if (primary) {
            MaterialButton(this)
        } else {
            MaterialButton(this, null, MaterialR.attr.materialButtonOutlinedStyle)
        }
        btn.text = label
        btn.isAllCaps = false
        btn.textSize = 14f
        btn.cornerRadius = dp(16)
        btn.insetTop = 0
        btn.insetBottom = 0
        return btn
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)

        window.statusBarColor = bg
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        if (token().isNullOrBlank()) {
            login()
        } else {
            dashboard("Home")
        }
    }

    private fun login() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(24), dp(28), dp(24))
            setBackgroundColor(bg)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val image = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }

        box.addView(
            card(image),
            LinearLayout.LayoutParams(-1, dp(150))
        )

        box.addView(
            text("Welcome to Miao Library", 28f).apply {
                gravity = Gravity.CENTER
                typeface = headlineTypeface()
            },
            LinearLayout.LayoutParams(-1, dp(70))
        )

        box.addView(
            text("Your library, wherever you are", 15f, muted).apply {
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(-1, dp(38))
        )

        val fieldRadius = dp(16).toFloat()

        val userLayout = TextInputLayout(this).apply {
            hint = "Library username"
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            setBoxCornerRadii(fieldRadius, fieldRadius, fieldRadius, fieldRadius)
        }
        val user = TextInputEditText(userLayout.context).apply { setSingleLine() }
        userLayout.addView(user)

        val passLayout = TextInputLayout(this).apply {
            hint = "Password"
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            setBoxCornerRadii(fieldRadius, fieldRadius, fieldRadius, fieldRadius)
            endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        }
        val pass = TextInputEditText(passLayout.context).apply {
            setSingleLine()
            inputType =
                InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        passLayout.addView(pass)

        box.addView(
            userLayout,
            LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, dp(12), 0, dp(10))
            }
        )

        box.addView(
            passLayout,
            LinearLayout.LayoutParams(-1, -2)
        )

        val signIn = button("Sign in")

        box.addView(
            signIn,
            LinearLayout.LayoutParams(-1, dp(54)).apply {
                setMargins(0, dp(20), 0, 0)
            }
        )

        val attemptLogin = attemptLogin@{
            if (user.text.isNullOrBlank() || pass.text.isNullOrBlank()) {
                toast("Enter your username and password.")
                return@attemptLogin
            }

            signIn.isEnabled = false
            signIn.text = "Signing in…"

            request(
                "/login",
                "POST",
                JSONObject()
                    .put("username", user.text.toString().trim())
                    .put("password", pass.text.toString()),
                null
            ) { ok, response ->
                runOnUiThread {
                    signIn.isEnabled = true
                    signIn.text = "Sign in"

                    if (!ok) {
                        toast("Login failed.")
                        return@runOnUiThread
                    }

                    try {
                        val j = JSONObject(response)
                        val access =
                            j.optString("access_token")
                                .ifBlank { j.optString("token") }

                        if (access.isBlank()) throw Exception()

                        prefs().edit()
                            .putString("access_token", access)
                            .putString(
                                "username",
                                user.text.toString().trim()
                            )
                            .apply()

                        dashboard("Home")
                    } catch (_: Exception) {
                        toast("Invalid gateway response.")
                    }
                }
            }
        }

        signIn.setOnClickListener { attemptLogin() }
        pass.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { attemptLogin(); true } else false
        }

        root.addView(
            box,
            LinearLayout.LayoutParams(-1, -2)
        )

        root.alpha = 0f
        setContentView(root)
        root.animate().alpha(1f).setDuration(240).start()
    }

    private fun dashboard(section: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(12))
        }

        header.addView(
            ImageView(this).apply {
                setImageResource(R.drawable.logo)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            },
            LinearLayout.LayoutParams(dp(64), dp(64))
        )

        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        heading.addView(
            text("Miao Library", 23f).apply {
                typeface = headlineTypeface()
            }
        )

        heading.addView(
            text("Welcome back, ${username()}", 14f, muted)
        )

        header.addView(
            heading,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        root.addView(header)

        content = FrameLayout(this)

        root.addView(
            content,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val nav = BottomNavigationView(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadii = floatArrayOf(
                    dp(24).toFloat(), dp(24).toFloat(),
                    dp(24).toFloat(), dp(24).toFloat(),
                    0f, 0f,
                    0f, 0f
                )
            }
            elevation = dp(8).toFloat()
            inflateMenu(R.menu.bottom_nav_menu)
            itemIconTintList = ContextCompat.getColorStateList(this@MainActivity, R.color.nav_item_tint)
            itemTextColor = ContextCompat.getColorStateList(this@MainActivity, R.color.nav_item_tint)
            selectedItemId = when (section) {
                "Home" -> R.id.nav_home
                "Catalogue" -> R.id.nav_catalogue
                "My Books" -> R.id.nav_books
                "Account" -> R.id.nav_account
                else -> R.id.nav_home
            }
            setOnItemSelectedListener { item ->
                val target = when (item.itemId) {
                    R.id.nav_home -> "Home"
                    R.id.nav_catalogue -> "Catalogue"
                    R.id.nav_books -> "My Books"
                    R.id.nav_account -> "Account"
                    else -> "Home"
                }
                dashboard(target)
                true
            }
        }

        root.addView(
            nav,
            LinearLayout.LayoutParams(-1, -2)
        )

        setContentView(root)
        showSection(section)
    }

    private fun showSection(section: String) {
        content.removeAllViews()

        val scroll = ScrollView(this)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(36))
        }

        // The Home heading is intentionally removed.
        if (section != "Home") {
            body.addView(
                text(section, 26f).apply {
                    gravity = Gravity.CENTER
                    typeface = headlineTypeface()
                    setPadding(0, dp(8), 0, dp(8))
                }
            )
        }

        when (section) {
            "Home" -> home(body)
            "Catalogue" -> catalogue(body)
            "My Books" -> books(body)
            "Account" -> account(body)
        }

        scroll.addView(body)
        content.addView(scroll)

        body.alpha = 0f
        body.animate().alpha(1f).setDuration(200).start()
    }

    private fun home(body: LinearLayout) {
    body.addView(text("A welcoming space for learning, discovery and connection", 16f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) })
    val exploreText = text("Arunachal Pradesh's first futuristic New Age Learning Centre — a paradise for book lovers, competitive aspirants, and lifelong learners nestled in the heart of Miao, Changlang district.", 16f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
    exploreText.textAlignment = View.TEXT_ALIGNMENT_CENTER
    body.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(exploreText) }), LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(16)) })
    val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    val c = button("Catalogue", true).apply { textSize = 15f }
    val b = button("My Books", true).apply { textSize = 15f }
    quick.addView(c, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(0, 0, dp(6), 0) })
    quick.addView(b, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(6), 0, 0, 0) })
    c.setOnClickListener { dashboard("Catalogue") }; b.setOnClickListener { dashboard("My Books") }; body.addView(quick)
    body.addView(text("Library updates", 20f).apply { gravity = Gravity.CENTER; typeface = headlineTypeface(); setPadding(0, dp(24), 0, dp(10)) })
    val loading = card(loadingRow("Loading announcements…")); body.addView(loading)
    request("/cms/content", "GET", null, token()) { ok, response -> runOnUiThread { body.removeView(loading); if (!ok) body.addView(card(text("Announcements are temporarily unavailable.", 14f, muted))) else { val items = arrayFrom(response, "items", "content", "announcements"); if (items.length() == 0) body.addView(card(text("No current announcements.", 14f, muted))) else for (i in 0 until items.length()) { val item = items.optJSONObject(i) ?: continue; val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(text(first(item, "title", "name").ifBlank { "Published announcement" }, 17f).apply { typeface = headlineTypeface() }); addView(text(first(item, "body", "description", "html", "content"), 14f, muted).apply { setPadding(0, dp(8), 0, 0) }) }; body.addView(card(box), LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }) } } } }
}

    private fun catalogue(body: LinearLayout) {
        val searchRadius = dp(16).toFloat()
        val inputLayout = TextInputLayout(this).apply {
            hint = "Search books, authors or subjects"
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
            setBoxCornerRadii(searchRadius, searchRadius, searchRadius, searchRadius)
            endIconMode = TextInputLayout.END_ICON_CLEAR_TEXT
        }
        val input = TextInputEditText(inputLayout.context).apply {
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        inputLayout.addView(input)

        body.addView(
            inputLayout,
            LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, dp(14), 0, dp(10))
            }
        )

        val search = button("Search catalogue")

        body.addView(
            search,
            LinearLayout.LayoutParams(-1, dp(52))
        )

        val output = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        body.addView(
            output,
            LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, dp(18), 0, 0)
            }
        )

        search.setOnClickListener {
            searchCatalogue(
                input.text.toString(),
                output,
                search
            )
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchCatalogue(input.text.toString(), output, search)
                true
            } else false
        }

        searchCatalogue("", output, search)
    }

    private fun searchCatalogue(
        query: String,
        output: LinearLayout,
        search: Button
    ) {
        search.isEnabled = false
        output.removeAllViews()

        output.addView(loadingRow("Searching catalogue…"))

        request(
            "/catalogue/search?q=" +
                    URLEncoder.encode(query, "UTF-8"),
            "GET",
            null,
            token()
        ) { ok, response ->
            runOnUiThread {
                search.isEnabled = true
                output.removeAllViews()

                if (!ok) {
                    output.addView(
                        card(
                            text(
                                "Catalogue unavailable.",
                                14f,
                                muted
                            )
                        )
                    )
                    return@runOnUiThread
                }

                val items = arrayFrom(
                    response,
                    "items",
                    "results",
                    "records",
                    "books"
                )

                if (items.length() == 0) {
                    output.addView(
                        card(
                            text(
                                "No catalogue records found.",
                                14f,
                                muted
                            )
                        )
                    )
                } else {
                    for (i in 0 until items.length()) {
                        val item =
                            items.optJSONObject(i) ?: continue

                        val box = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL

                            addView(
                                text(
                                    first(item, "title").ifBlank {
                                        "Untitled"
                                    },
                                    18f
                                ).apply {
                                    typeface = headlineTypeface()
                                }
                            )

                            addIfPresent(
                                this,
                                "Author",
                                item,
                                "author"
                            )

                            addIfPresent(
                                this,
                                "Library",
                                item,
                                "library"
                            )

                            addIfPresent(
                                this,
                                "Availability",
                                item,
                                "availability"
                            )

                            addIfPresent(
                                this,
                                "Call number",
                                item,
                                "call_number"
                            )

                            addIfPresent(
                                this,
                                "Barcode",
                                item,
                                "barcode"
                            )

                            addIfPresent(
                                this,
                                "Holdings",
                                item,
                                "holding_count"
                            )

                            addView(
                                text(
                                    "Tap for complete book details",
                                    12f,
                                    ink
                                ).apply {
                                    setPadding(0, dp(12), 0, 0)
                                }
                            )
                        }

                        val itemCard = card(box)

                        itemCard.setOnClickListener {
                            openDetails(item)
                        }

                        output.addView(
                            itemCard,
                            LinearLayout.LayoutParams(-1, -2).apply {
                                setMargins(0, 0, 0, dp(12))
                            }
                        )
                    }
                }
            }
        }
    }

    private fun addIfPresent(
        parent: LinearLayout,
        label: String,
        item: JSONObject,
        key: String
    ) {
        val value = first(item, key)

        if (value.isNotBlank()) {
            parent.addView(
                text("$label: $value", 13f, muted)
            )
        }
    }

    private fun openDetails(item: JSONObject) {
        val id = first(item, "biblionumber")

        if (id.isBlank()) {
            details(item)
            return
        }

        request(
            "/book-details/$id",
            "GET",
            null,
            token()
        ) { ok, response ->
            runOnUiThread {
                if (ok) {
                    try {
                        val j = JSONObject(response)

                        details(
                            j.optJSONObject("book")
                                ?: j.optJSONObject("record")
                                ?: j
                        )
                    } catch (_: Exception) {
                        details(item)
                    }
                } else {
                    details(item)
                }
            }
        }
    }

    private fun details(item: JSONObject) {
        dashboard("Catalogue")
        content.removeAllViews()

        val scroll = ScrollView(this)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(30))
        }

        body.addView(
            text("Book details", 25f).apply {
                typeface = headlineTypeface()
            }
        )

        arrayOf(
            "title",
            "subtitle",
            "author",
            "authors",
            "publisher",
            "publication",
            "publication_year",
            "year",
            "isbn",
            "isbn13",
            "isbn10",
            "call_number",
            "callnumber",
            "shelfmark",
            "library",
            "location",
            "availability",
            "status",
            "barcode",
            "holding_count",
            "copy_count",
            "holdings",
            "item_type",
            "notes",
            "biblionumber"
        ).forEach { field ->
            val value = displayValue(item, field)

            if (value.isNotBlank()) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL

                    addView(
                        text(
                            field
                                .replace('_', ' ')
                                .replaceFirstChar {
                                    it.uppercase()
                                },
                            12f,
                            muted
                        )
                    )

                    addView(
                        text(value, 16f).apply {
                            setPadding(0, dp(4), 0, 0)
                        }
                    )
                }

                body.addView(
                    card(row),
                    LinearLayout.LayoutParams(-1, -2).apply {
                        setMargins(0, 0, 0, dp(9))
                    }
                )
            }
        }

        scroll.addView(body)
        content.addView(scroll)
    }

    private fun books(body: LinearLayout) {
        body.addView(
            text("Currently issued", 19f).apply {
                setTypeface(typeface, 1)
                setPadding(0, dp(14), 0, dp(10))
            }
        )

        val current = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        current.addView(loadingRow("Loading your books…"))
        body.addView(current)

        request(
            "/my-books",
            "GET",
            null,
            token()
        ) { ok, response ->
            runOnUiThread {
                current.removeAllViews()
                if (!ok) {
                    current.addView(
                        card(
                            text(
                                "Unable to load your books.",
                                14f,
                                muted
                            )
                        )
                    )
                } else {
                    val items = arrayFrom(
                        response,
                        "books",
                        "items",
                        "issues",
                        "current",
                        "current_books"
                    )

                    currentIssueKeys.clear()
                    for (i in 0 until items.length()) {
                        items.optJSONObject(i)?.let { currentIssueKeys.addAll(issueKeys(it)) }
                    }

                    if (items.length() == 0) {
                        current.addView(
                            card(
                                text(
                                    "You have no currently issued books.",
                                    14f,
                                    muted
                                )
                            )
                        )
                    } else {
                        records(items, current, true)
                    }
                }
            }
        }

        body.addView(
            text("Previous issues", 19f).apply {
                setTypeface(typeface, 1)
                setPadding(0, dp(24), 0, dp(10))
            }
        )

        val history = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        body.addView(history)

        val historyButton = button(
            "Load issue history / previous issues",
            true
        ).apply {
            backgroundTintList = ColorStateList.valueOf(Color.rgb(72, 105, 112))
            textSize = 14f
        }

        body.addView(
            historyButton,
            LinearLayout.LayoutParams(-1, dp(52)).apply {
                setMargins(0, 0, 0, dp(12))
            }
        )

        history.addView(
            card(
                text(
                    "Tap the button above to load your previous issued books.",
                    14f,
                    muted
                )
            )
        )

        historyButton.setOnClickListener {
            loadHistory(history)
        }
    }

    private fun loadHistory(output: LinearLayout) {
        output.removeAllViews()

        output.addView(card(loadingRow("Loading previous issues…")))

        request(
            "/issue-history",
            "GET",
            null,
            token()
        ) { ok, response ->
            runOnUiThread {
                output.removeAllViews()

                if (!ok) {
                    output.addView(
                        card(
                            text(
                                "Unable to load issue history.",
                                14f,
                                muted
                            )
                        )
                    )
                    return@runOnUiThread
                }

                val items = arrayFrom(
                    response,
                    "items",
                    "history",
                    "issues",
                    "books",
                    "previous_issues",
                    "previousIssues",
                    "returned_books",
                    "past_issues",
                    "circulation_history",
                    "circulationHistory",
                    "issue_history",
                    "issueHistory",
                    "results",
                    "records",
                    "data"
                )

                if (items.length() == 0) {
                    output.addView(
                        card(
                            text(
                                "No previous issues found.",
                                14f,
                                muted
                            )
                        )
                    )
                } else {
                    records(items, output, false)
                }
            }
        }
    }

    private fun records(
        items: JSONArray,
        output: LinearLayout,
        current: Boolean
    ) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            if (!current && isCurrentIssue(item)) continue

            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL

                addView(
                    text(
                        first(
                            item,
                            "title",
                            "name"
                        ).ifBlank {
                            "Untitled"
                        },
                        17f
                    ).apply {
                        typeface = headlineTypeface()
                    }
                )

                addIfPresent(
                    this,
                    "Author",
                    item,
                    "author"
                )

                addIfPresent(
                    this,
                    "Library",
                    item,
                    "library"
                )

                addFirstPresent(
                    this,
                    "Issued date",
                    item,
                    "checkout_date",
                    "date_issued",
                    "issued_date",
                    "issue_date",
                    "date_checkout"
                )

                addFirstPresent(
                    this,
                    "Due date",
                    item,
                    "date_due",
                    "due_date",
                    "duedate",
                    "due"
                )

                addFirstPresent(
                    this,
                    "Renewed date",
                    item,
                    "date_renewed",
                    "renewed_date",
                    "renewal_date",
                    "renewed_until"
                )

                addFirstPresent(
                    this,
                    "Renewals",
                    item,
                    "renewals",
                    "renewal_count"
                )

                addFirstPresent(
                    this,
                    "Returned date",
                    item,
                    "date_returned",
                    "returned_date",
                    "return_date",
                    "checkin_date",
                    "date_checkin"
                )

                addIfPresent(
                    this,
                    "Barcode",
                    item,
                    "barcode"
                )
            }

            output.addView(
                card(box),
                LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, dp(12))
                }
            )
        }
    }

    private fun isCurrentIssue(item: JSONObject): Boolean {
        if (currentIssueKeys.isEmpty()) return false
        return issueKeys(item).any { currentIssueKeys.contains(it) }
    }

    private fun issueKeys(item: JSONObject): Set<String> {
        val keys = mutableSetOf<String>()

        fun add(prefix: String, value: String) {
            val v = value.trim()
            if (v.isNotBlank() && v != "null") keys.add("$prefix:$v")
        }

        add("issue", first(item, "issue_id", "issueid", "issueId", "checkout_id", "checkoutId", "loan_id", "loanId"))

        val barcode = first(item, "barcode", "item_barcode")
        val issued = first(item, "checkout_date", "date_issued", "issued_date", "issue_date", "date_checkout")
        val due = first(item, "date_due", "due_date", "duedate", "due")

        if (barcode.isNotBlank() && issued.isNotBlank()) add("barcode-issued", "$barcode|$issued")
        if (barcode.isNotBlank() && due.isNotBlank()) add("barcode-due", "$barcode|$due")

        return keys
    }

    private fun isReturnedIssue(item: JSONObject): Boolean {
        val returnedKeys = listOf("date_returned", "returned_date", "return_date", "checkin_date", "date_checkin")
        if (returnedKeys.any {
                val value = item.optString(it, "").trim()
                value.isNotBlank() && value != "null"
            }) return true

        val status = first(item, "status", "issue_status", "item_status", "loan_status").lowercase()
        if (status.contains("return") || status.contains("checkin") || status.contains("closed")) return true
        if (status.contains("issue") || status.contains("checkout") || status.contains("loan") || status.contains("out")) return false
        return false
    }

    private fun account(body: LinearLayout) {
    body.addView(card(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; addView(text("Library account", 21f).apply { gravity = Gravity.CENTER; typeface = headlineTypeface() }); addView(text(username(), 16f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }); addView(text("Your Koha patron account", 13f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }) }), LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(14), 0, dp(16)) })
    val my = button("View my books", false).apply { textSize = 15f }; body.addView(my, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(10)) }); my.setOnClickListener { dashboard("My Books") }
    val refresh = button("Refresh account", false).apply { textSize = 15f }; body.addView(refresh, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, 0, 0, dp(10)) }); refresh.setOnClickListener { dashboard("Account") }
    val logout = button("Log out", true).apply { backgroundTintList = ColorStateList.valueOf(Color.rgb(155, 76, 76)); textSize = 15f }; body.addView(logout, LinearLayout.LayoutParams(-1, dp(52))); logout.setOnClickListener { prefs().edit().clear().apply(); login() }

    val footer = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(0, dp(34), 0, dp(12))
    }
    val website = text("Our Official Website : miaolibrary.in", 14f, ink).apply {
        gravity = Gravity.CENTER
        typeface = headlineTypeface()
        isClickable = true
        isFocusable = true
        foreground = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.list_selector_background)
        setOnClickListener {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://miaolibrary.in")))
        }
    }
    footer.addView(website)
    footer.addView(text("© Sub Divisional Library, Miao. All Rights Reserved.", 12f, muted).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, 0)
    })
    body.addView(footer)
}

    private fun displayValue(
        item: JSONObject,
        key: String
    ): String {
        val value = item.opt(key) ?: return ""

        if (value is JSONArray) {
            return prettyArray(value)
        }

        if (value is JSONObject) {
            return value.toString()
        }

        return value.toString().trim()
    }

    private fun prettyArray(array: JSONArray): String {
        val lines = mutableListOf<String>()

        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i)

            if (obj != null) {
                val keys = listOf(
                    "item_type",
                    "current_library",
                    "home_library",
                    "collection",
                    "shelving_location",
                    "call_number",
                    "copy_number",
                    "status",
                    "notes",
                    "date_due",
                    "barcode"
                )

                val parts = keys.mapNotNull { key ->
                    obj.optString(key)
                        .takeIf { it.isNotBlank() }
                        .let {
                            if (it == null) {
                                null
                            } else {
                                "${key.replace('_', ' ')}: $it"
                            }
                        }
                }

                lines.add(
                    if (parts.isEmpty()) {
                        obj.toString()
                    } else {
                        parts.joinToString("\n")
                    }
                )
            } else {
                lines.add(array.optString(i))
            }
        }

        return lines.joinToString("\n\n")
    }

    private fun first(
        item: JSONObject,
        vararg keys: String
    ): String {
        for (key in keys) {
            val value = displayValue(item, key)

            if (value.isNotBlank() && value != "null") {
                return value
            }
        }

        return ""
    }

    private fun arrayFrom(
        raw: String,
        vararg keys: String
    ): JSONArray {
        return try {
            val trimmed = raw.trim()

            if (trimmed.startsWith("[")) {
                return JSONArray(trimmed)
            }

            val root = JSONObject(trimmed)

            for (key in keys) {
                val direct = root.opt(key)

                if (direct is JSONArray) {
                    return direct
                }

                if (direct is JSONObject) {
                    val nested = findArray(
                        direct,
                        keys.toSet()
                    )

                    if (nested.length() > 0) {
                        return nested
                    }
                }
            }

            findArray(root, keys.toSet())
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun findArray(
        obj: JSONObject,
        wanted: Set<String>
    ): JSONArray {
        val preferred = listOf(
            "items",
            "history",
            "issues",
            "books",
            "previous_issues",
            "previousIssues",
            "returned_books",
            "past_issues",
            "results",
            "records",
            "data"
        )

        for (key in preferred) {
            val value = obj.opt(key)

            if (
                value is JSONArray &&
                (wanted.contains(key) ||
                        key == "data" ||
                        key == "items")
            ) {
                return value
            }

            if (value is JSONObject) {
                val nested = findArray(value, wanted)

                if (nested.length() > 0) {
                    return nested
                }
            }
        }

        val names = obj.keys()

        while (names.hasNext()) {
            val key = names.next()
            val value = obj.opt(key)

            if (
                value is JSONArray &&
                value.length() > 0 &&
                (
                        key.lowercase().contains("histor") ||
                                key.lowercase().contains("issue") ||
                                key.lowercase().contains("book")
                        )
            ) {
                return value
            }

            if (value is JSONObject) {
                val nested = findArray(value, wanted)

                if (nested.length() > 0) {
                    return nested
                }
            }
        }

        return JSONArray()
    }

    private fun request(
        path: String,
        method: String,
        payload: JSONObject?,
        auth: String?,
        callback: (Boolean, String) -> Unit
    ) {
        thread {
            var connection: HttpURLConnection? = null

            try {
                connection =
                    (URL(gateway + path).openConnection()
                            as HttpURLConnection).apply {
                        requestMethod = method
                        connectTimeout = 15000
                        readTimeout = 20000

                        setRequestProperty(
                            "Accept",
                            "application/json"
                        )

                        if (auth != null) {
                            setRequestProperty(
                                "Authorization",
                                "Bearer $auth"
                            )
                        }

                        if (payload != null) {
                            doOutput = true

                            setRequestProperty(
                                "Content-Type",
                                "application/json"
                            )
                        }
                    }

                if (payload != null) {
                    connection.outputStream.use {
                        it.write(
                            payload.toString().toByteArray()
                        )
                    }
                }

                val code = connection.responseCode

                val stream =
                    if (code in 200..299) {
                        connection.inputStream
                    } else {
                        connection.errorStream
                    }

                val response =
                    stream?.bufferedReader()?.use {
                        it.readText()
                    }.orEmpty()

                callback(code in 200..299, response)
            } catch (error: Exception) {
                callback(false, error.message.orEmpty())
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun toast(message: String) =
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()
}